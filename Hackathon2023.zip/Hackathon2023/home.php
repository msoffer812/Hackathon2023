<?php
session_start();
require_once "pdo.php";
?>
<html>
<title>Home</title>
<body>
<?php
if ( ! isset($_SESSION["user"]) ) {
    ?><h1>Log in to access the cool games!</h1><?php }
else {

?>
<a href="logout.php">Logout</a>
<?php } ?> </body>
</html>