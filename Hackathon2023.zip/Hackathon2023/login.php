<?php // Do not put any HTML above this line
require_once "pdo.php";
session_start();

if ( isset($_POST['cancel'] ) ) {
    // Redirect the browser to game.php
    header("Location: home.php");
    return;
}

// Check to see if we have some POST data, if we do process it
if ( isset($_POST["email"]) && isset($_POST["pass"]) ) {
    if (strlen($_POST["email"]) < 1 || strlen($_POST["pass"]) < 1) {
        $_SESSION["error"] = "Email and password are required";
        header("Location: login.php");
        return;
    } else {
        $emailStr = str_split($_POST["email"]);
        for ($x = 0; $x < strlen($_POST["email"]); $x++) {
            if ($emailStr[$x] == "@") {
                $check2 = "1";
            }
        }
        if ($check2 !== "1") {
            $_SESSION["error"] = "Email must have an at-sign (@)";
            header("Location: login.php");
            return;
        } else {
            $_SESSION["email"] = $_POST["email"];
            $_SESSION["password"] = $_POST["pass"];
            $sql = "SELECT*FROM users WHERE email = :eml";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array(
                ':eml' => $_SESSION["email"]
            ));
            $row = $stmt->fetch(PDO:: FETCH_ASSOC);
            if ($row === false) {
                $_SESSION["error"] = "Incorrect email";
                header("Location: login.php");
                return;
            }
            elseif ($row['password'] !== $_SESSION["password"]) {
                $_SESSION["error"] = "Incorrect Password";
                header("Location: login.php");
                return;
            }
                else {
                    $_SESSION["user"] = $_POST["email"];
                    $_SESSION["success"] = "Logged in.";
                    error_log("Login success" . $_SESSION["email"]);
                    header("Location: flashcards.php");
                    return;
                    }
                }
            }
}

// Fall through into the View
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="main.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-3.1.1.min.js"></script>
</head>
<body style="background-color:black;">
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="#"></a>
        <a class="navbar-brand" href="#">
            <img src="cyberprologo.png" width="300" height="180" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="about.html">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="new.php">Sign Up</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="matching.php">Matching Game</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="flashcards.php">Flashcards</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
<h1 style="font-size: 300%; color: white; text-align: center;"">Please Log In</h1>
<?php
// flash message
if ( isset($_SESSION["error"]) ) {
  echo('<p style="color:red">'.htmlentities($_SESSION["error"])."</p>\n");
  unset($_SESSION["error"]);
}
if ( isset($_SESSION["success"]) ) {
  echo('<p style="color:green">'.htmlentities($_SESSION["success"])."</p>\n");
  unset($_SESSION["success"]);
}
?>
    <form method="post" style="color: grey;
  font-size: 150%;
  padding-top: 5vw;
  padding-bottom: 5vw;
  padding-left: 20vw;
  padding-right: 30vw;
  margin-left: 10vw;
  margin-right: 40vw;
   border: thin solid white">
<label for="nam">Email</label>
<input type="text" name="email" id="nam"><br/>
<label for="id_1723">Password</label>
<input type="text" name="pass" id="id_1723"><br/>
<input type="submit" style="margin-top: 1vw;"value="Log In">
<input type="submit" style="margin-top: 1vw;" name="cancel" value="Cancel">
</form>
</div>
</body>
</html>