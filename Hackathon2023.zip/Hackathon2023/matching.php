<?php
session_start();
require_once "pdo.php";

//password
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Memory Game</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" href="memoryCards.css">
    <link href="main.css" rel="stylesheet">
    <title>Flash Cards</title>
</head>
<body>
<header>
    <div style="top:0; position: fixed;">
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="#"></a>
        <a class="navbar-brand" href="#">
            <img src="cyberprologo.png" width="300" height="180" alt=""></a>
            <a class="navbar-brand" href="#">
                <?php if (isset($_SESSION["user"])) {
                    echo("Hello, ".($_SESSION["user"]). "!");
                } ?>
                <a class="navbar-brand" href="logout.php">
                    Logout
                </a>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="about.html">Back</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="new.php">Sign Up</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="matching.php">Matching Game</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="flashcards.php">Flashcards</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
    </div>
</header>
<?php if ( ! isset($_SESSION["user"]) ) {?>
    <h1 style="color: grey; margin-right: -5vw; padding-top: 20vw;">Please Log In</h1>
<?php } else { ?>

//This codes the memory game
    <section class="memory-game">

        <div class="memory-card" data-framework="aurelia">
            <p class="front-face">True or False: It does not matter how you spell words when searching the Internet</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="aurelia">
            <p class="front-face">False</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="vue">
            <p class="front-face">Three examples of personal information are:</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="vue">
            <p class="front-face">Passwords, credit card numbers, home address</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="angular">
            <p class="front-face">What is phishing?</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="angular">
            <p class="front-face">An act of deception to get people to share their personal information.</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="ember">
            <p class="front-face">What should you remember to do when you finish using a public computer?</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="ember">
            <p class="front-face">Log off of all your accounts</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="backbone">
            <p class="front-face">What should you do if someone messages you, claiming to know you or be in your school?</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="backbone">
            <p class="front-face">Tell a parent or trusted adult</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="react">
            <p class="front-face">What is a virus?</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

        <div class="memory-card" data-framework="react">
            <p class="front-face">Something that can infect your computer</p>
            <img class="back-face" src="cyberprologo.png" alt="Logo" />
        </div>

    </section>
    <script src="scripts.js"></script>
<?php } ?>
</body>
</html>
