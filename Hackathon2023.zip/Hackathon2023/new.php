<?php
session_start();
require_once "pdo.php";

//link for logout button
if ( isset($_POST['cancel']) ) {
    header("Location: about.html");
    return;
}

//If we get data:
//Validation
  if ( isset($_POST["email"]) && isset($_POST["pass"]) && isset($_POST["pass2"]) ) {
      if (strlen($_POST["email"]) < 1 || strlen($_POST["pass"]) < 1) {
          $_SESSION["error"] = "Email and password are required";
          header("Location: new.php");
          return;
      } else {
          $emailStr = str_split($_POST["email"]);
          for ($x = 0; $x < strlen($_POST["email"]); $x++) {
              if ($emailStr[$x] == "@") {
                  $check2 = "1";
              }
          }
              if ($_POST["pass"] !== $_POST["pass2"]) {
                  $_SESSION["error"] = "Passwords must match";
                  header("Location: new.php");
                  return;
              } elseif ($check2 !== "1") {
                  $_SESSION["error"] = "Email must have an at-sign (@)";
                  header("Location: new.php");
                  return;
              } else {
                  $_SESSION["email"] = $_POST["email"];
                  $_SESSION["password"] = $_POST["pass"];
                  header("Location: new.php");
                  $sql = "INSERT INTO users (email, password)
                    VALUES(:eml, :psw)";
                  $stmt =  $pdo->prepare($sql);
                  $stmt -> execute(array(
                          ':eml' => $_SESSION["email"],
                          ':psw' => $_SESSION["password"],
                  ));
                  $_SESSION["success"] = "Account Created";
                  unset($_SESSION["email"]);
                  header("Location: login.php");
                  return;
          }
      }
  }

// Fall through into the View
?>
<html><head>
    <title>Create a New Account</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="main.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-3.1.1.min.js"></script>
</head><body style="background-color:black;">
<nav class="navbar navbar-expand-lg navbar-dark fs-5">
    <div class="container">
        <a class="navbar-brand" href="#"></a>
        <a class="navbar-brand" href="#">
            <img src="cyberprologo.png" width="300" height="180" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="about.html" >About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="new.php">Sign Up</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="matching.php">Matching Game</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="flashcards.php">Flashcards</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
  <h1 style="font-size: 300%; color: white; text-align: center;">Create an Account</h1>
  <?php
  if (isset($_SESSION["error"])) {
      echo('<p style="color: red;">'.htmlentities($_SESSION["error"])."</p>\n");
      unset($_SESSION["error"]);
    }
  ?>
  <form method="post" style="color: grey;
  font-size: 150%;
  padding-top: 5vw;
  padding-bottom: 5vw;
  padding-left: 20vw;
  margin-left: 15vw;
  margin-right: 15vw;
  margin-left: 15vw;
   border: thin solid white">
  <p>Email:<input type="text" name="email" size="40"></p>
  <p>Password:<input type="text" name="pass"></p>
  <p>Re-enter Your Password:<input type="text" name="pass2"></p>
  <p><input type="submit" value="Add" /></p>
  <p><input type="submit" name="cancel" value="Cancel" /></p>
</form>
</body>
</html>