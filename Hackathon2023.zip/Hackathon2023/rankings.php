<?php
session_start();
require_once "pdo.php";
?>
<html>
<title>Home</title>
<body>
<?php
if ( ! isset($_SESSION["user"]) ) {
    ?><h1>Log in to access the cool games!</h1>
<?php } else {?>
    <table>
    <?php
    $stmt = $pdo->query("SELECT email FROM users");
    while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
        echo("<tr><td>");
        echo(htmlentities($row['email']));
        /*echo("</td><td>");
        echo(htmlentities($row['score']));
        echo("</td></tr>");*/
    } ?>
    </table>
    <a href="logout.php">Logout</a>
<?php } ?> </body>
</html>
